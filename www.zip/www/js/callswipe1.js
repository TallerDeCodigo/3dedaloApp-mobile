new Swipe(document.getElementById('mask'));
  var slider = new Swipe(document.getElementById('mask'));