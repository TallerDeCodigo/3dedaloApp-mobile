new Swipe(document.getElementById('shower'));
  var slider = new Swipe(document.getElementById('shower'));